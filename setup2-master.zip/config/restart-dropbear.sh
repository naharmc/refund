            echo "Servie dropbear restart .................tunggu sebentar"
            sleep 0.3
            service dropbear restart
            echo ""
	    echo "Script Created by http://www.sshinjector.net"
            echo "Terimakasih sudah berlanggan di sshinjector.net"
