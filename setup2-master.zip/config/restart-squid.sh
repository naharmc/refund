            echo "Servie squid restart .................tunggu sebentar"
            sleep 0.3
            service squid3 restart
            echo ""
	    echo "Script Created by http://www.sshinjector.net"
            echo "Terimakasih sudah berlanggan di sshinjector.net"
